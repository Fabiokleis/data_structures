#!/bin/sh

echo "compilando e rodando tudo!"
echo "exercicio 01:"
gcc exercicio1.c -o e01 && ./e01
echo "exercicio 02:"
gcc exercicio1.c -o e02 && ./e02

