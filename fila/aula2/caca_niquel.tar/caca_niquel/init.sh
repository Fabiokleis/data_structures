#!/bin/sh
time ./build/main
