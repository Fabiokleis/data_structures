# to Run

Para rodar voce precisará de um compilador C e o Cmake...

### follow:

mkdir -p build && cd build

cmake ..

make

./list
